import pytest
from fastapi.testclient import TestClient
import sluice.server
from sluice.server import app

def test_list_routes():
    client = TestClient(app)
    # Print routes for debugging
    for route in app.routes:
        print(f"Path: {route.path}, Methods: {route.methods}")
        
    response = client.post("/v1/admin/drain")
    assert response.status_code == 200
    assert sluice.server.BANK.is_draining is True
