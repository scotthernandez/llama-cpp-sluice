import ctypes
import asyncio
import os
import time
import uuid
import json
import re
import argparse
from typing import Optional, List, Dict, Any, Generator, Union
from fastapi import FastAPI, HTTPException, Body, Header, Path, Response, Depends
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
import llama_cpp
from prometheus_client import Counter, Gauge, Histogram, generate_latest, CONTENT_TYPE_LATEST

from .bank import TokenBank, BankSaturated
from .engine import SluiceEngine
from .pools import PoolConfig, DEFAULT_POOLS
from .middleware.trimmer import MiddleOutTrimmer

# --- Config (Minimal for Demo) ---
MODEL_PATH = os.getenv("SLUICE_MODEL_PATH", "/models/gguf/model.gguf")
BATCH_SIZE = 512
UBATCH_SIZE = 256
PORT = 8001
HOST = "0.0.0.0"

app = FastAPI(title="Sluice Pilot")

ENGINE: Optional[SluiceEngine] = None
BANK: Optional[TokenBank] = None

class ChatMessage(BaseModel):
    role: str
    content: Optional[str] = None

class ChatCompletionRequest(BaseModel):
    model: str = "sluice-model"
    messages: List[ChatMessage]
    max_tokens: int = 128
    stream: bool = False

@app.on_event("startup")
async def startup():
    global ENGINE, BANK
    pools = [PoolConfig(name="precision", max_tokens=8192)]
    ENGINE = SluiceEngine(MODEL_PATH, pools)
    BANK = TokenBank(["precision"], {"precision": 8192}, 1000)

@app.post("/v1/chat/completions")
async def chat(request: ChatCompletionRequest):
    sid = await BANK.acquire("precision", 1024)
    try:
        prompt = ""
        for m in request.messages: prompt += f"{m.role}: {m.content}\n"
        prompt += "assistant: "
        
        m_ptr, c_ptr = ENGINE.get_model_ptr(), ENGINE.get_context_ptr("precision")
        p_bytes = prompt.encode('utf-8')
        tks = (llama_cpp.llama_token * (len(p_bytes) + 1))()
        n = llama_cpp.llama_tokenize(m_ptr, p_bytes, len(p_bytes), tks, len(tks), True, True)
        
        batch = llama_cpp.llama_batch_init(max(n, 512), 0, 1)
        batch.n_tokens = n
        for i in range(n): batch.token[i], batch.pos[i], batch.n_seq_id[i], batch.seq_id[i][0], batch.logits[i] = tks[i], i, 1, sid, (i == n-1)
        llama_cpp.llama_decode(c_ptr, batch)
        
        output = []
        for i in range(request.max_tokens):
            logits = llama_cpp.llama_get_logits(c_ptr)
            n_vocab = llama_cpp.llama_n_vocab(m_ptr)
            candidates = (llama_cpp.llama_token_data * n_vocab)()
            for k in range(n_vocab): candidates[k] = llama_cpp.llama_token_data(id=k, logit=logits[k], p=0.0)
            candidates_p = llama_cpp.llama_token_data_array(data=candidates, size=n_vocab, sorted=False)
            ntid = llama_cpp.llama_sample_token_greedy(c_ptr, ctypes.byref(candidates_p))
            
            if ntid == llama_cpp.llama_token_eos(m_ptr): break
            buf = ctypes.create_string_buffer(128)
            nb = llama_cpp.llama_token_to_piece(m_ptr, ntid, buf, 128, 0, False)
            output.append(buf[:nb].decode('utf-8', errors='ignore'))
            
            batch.n_tokens, batch.token[0], batch.pos[0], batch.logits[0] = 1, ntid, n + i, True
            llama_cpp.llama_decode(c_ptr, batch)
            
        return {"choices": [{"message": {"role": "assistant", "content": "".join(output)}}]}
    finally:
        ENGINE.remove_sequence("precision", sid)
        await BANK.release(sid)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host=HOST, port=PORT)
